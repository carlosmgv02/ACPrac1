# ACPrac1
Pràctica 1 Arquitectura de computadors.
Per a provar el funcionament amb les dades trobades, s'ha d'executar el fitxer *script* de la següent manera:

```bash
./script
```
En cas de voler provar el funcionament amb les dades modificades (utilitzat per fer les proves) s'ha d'executar la següent comanda:
```bash
./scriptModified
```
